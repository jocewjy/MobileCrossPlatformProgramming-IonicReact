import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'Week03-34804-JocelynWijaya',
  webDir: 'build',
  bundledWebRuntime: false
};

export default config;
